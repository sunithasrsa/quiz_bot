# core/reply_factory.py

from .constants import BOT_WELCOME_MESSAGE, PYTHON_QUESTION_LIST

# Initialize dictionaries to store user responses and scores
user_responses = {}
scores = {}

def record_current_answer(message, current_question_id, session):
    user_id = session['user_id']
    if current_question_id is None or current_question_id >= len(PYTHON_QUESTION_LIST):
        return False, "No more questions."

    current_question = PYTHON_QUESTION_LIST[current_question_id]
    correct_answer = current_question['correct_answer']
    user_answer = message

    # Validate the user's answer
    if user_answer not in current_question['options']:
        return False, "Invalid answer. Please choose a valid option."

    # Store the user's answer
    if user_id not in user_responses:
        user_responses[user_id] = {}
    user_responses[user_id][current_question_id] = user_answer

    # Check if the answer is correct
    if user_id not in scores:
        scores[user_id] = 0
    if user_answer == correct_answer:
        scores[user_id] += 1

    return True, None