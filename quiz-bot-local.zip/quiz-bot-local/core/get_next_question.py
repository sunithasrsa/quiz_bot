from .constants import BOT_WELCOME_MESSAGE, PYTHON_QUESTION_LIST
from .record_current_answer import record_current_answer
from .get_next_question import get_next_question
from .generate_final_response import generate_final_response

def get_next_question(current_question_id):
    if current_question_id is None:
        next_question_id = 0
    else:
        next_question_id = current_question_id + 1

    if next_question_id < len(PYTHON_QUESTION_LIST):
        next_question = PYTHON_QUESTION_LIST[next_question_id]
        return next_question, next_question_id
    else:
        return None, None
