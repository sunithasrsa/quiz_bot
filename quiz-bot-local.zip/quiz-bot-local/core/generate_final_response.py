from .constants import BOT_WELCOME_MESSAGE, PYTHON_QUESTION_LIST
from .record_current_answer import record_current_answer
from .get_next_question import get_next_question
from .generate_final_response import generate_final_response

from .record_current_answer import scores
from .constants import PYTHON_QUESTION_LIST

def generate_final_response(session):
    user_id = session['user_id']
    total_questions = len(PYTHON_QUESTION_LIST)
    correct_answers = scores.get(user_id, 0)
    return f"You've completed the quiz! Your score is {correct_answers} out of {total_questions}."